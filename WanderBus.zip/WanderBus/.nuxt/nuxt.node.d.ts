/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/shared-app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../node_modules/.pnpm/@nuxt+vite-builder@4.6.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7_supports-co_98b7115c5545bbdc901cf5a0456c716a/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@4.6.1_1d7079d1f07b289a571fe6a26de55eca/node_modules/@nuxt/nitro-server/dist/augments.d.mts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
