/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@4.6.1_1d7079d1f07b289a571fe6a26de55eca/node_modules/@nuxt/nitro-server/dist/augments.d.mts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/shared-app.config.d.ts" />
/// <reference path="types/shared-imports.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
